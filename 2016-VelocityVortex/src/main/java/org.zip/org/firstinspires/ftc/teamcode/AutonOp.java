package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.OpMode;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.lapeerftcrobotics.auton.AutonStateMachine1;
import org.lapeerftcrobotics.auton.AutonStateMachineInterface;
import org.lapeerftcrobotics.control.ControlLoopThread;
import org.lapeerftcrobotics.control.RobotController;
import org.lapeerftcrobotics.vision.OnCameraFrameCallbackInterface;
import org.lapeerftcrobotics.vision.OpenCVCameraActivityHelper;
import org.lapeerftcrobotics.vision.OpenCVCameraViewListener;
import org.opencv.core.Mat;

/**
 * Created by User on 10/14/2016.
 */
public class AutonOp extends OpMode implements OnCameraFrameCallbackInterface {

    public final static char BLUE_ALLIANCE = 'B';
    public final static char RED_ALLIANCE = 'R';

    public final static int AUTON_MODE_1 = 1;
    public final static int AUTON_MODE_2 = 2;
    public final static int AUTON_MODE_3 = 3;
    public final static int AUTON_MODE_4 = 4;
    public final static int AUTON_MODE_5 = 5;

    private char alliance = ' ';
    private int autonMode = 0;

    private AutonStateMachineInterface autonStateMachine = null;
    private RobotController robotController = null;
    private ControlLoopThread controlLoopThread = null;
    private ElapsedTime runtime = new ElapsedTime();
    private OpenCVCameraActivityHelper openCVCameraActivityHelper = null;

    public void setAlliance(char a) {
        this.alliance = a;
    }

    public void setAutonMode(int m) {
        this.autonMode = m;
    }

    public boolean isBlueAlliance() {
        if (this.alliance == BLUE_ALLIANCE)
            return true;
        else
            return false;
    }

    public boolean isRedAlliance() {
        if (this.alliance == RED_ALLIANCE)
            return true;
        else
            return false;
    }

    @Override
    public void init() {
        telemetry.addData("Status", "Initializing");

        openCVCameraActivityHelper = new OpenCVCameraActivityHelper();
        openCVCameraActivityHelper.init();

        robotController = new RobotController();
        robotController.init(hardwareMap);

        telemetry.addData("Status", "Initialized");
    }

    /*
 * Code to run ONCE when the driver hits PLAY
 */
    @Override
    public void start() {

        OpenCVCameraViewListener.getInstance().registerOnFrameCallbackListener(this);

        if (autonMode == AUTON_MODE_1) {
            autonStateMachine = new AutonStateMachine1();
        }

        autonStateMachine.setAutonOp(this);
        autonStateMachine.setRobotController(robotController);
        autonStateMachine.setRuntime(runtime);

        controlLoopThread = new ControlLoopThread();
        controlLoopThread.setAutonStateMachineInterface(autonStateMachine);
        controlLoopThread.setRobotController(robotController);
        controlLoopThread.setRunning(true);
        controlLoopThread.start();

        runtime.reset();
    }

        @Override
    public void loop() {

    }

    /*
     * Code to run ONCE after the driver hits STOP
     */
    @Override
    public void stop() {
        openCVCameraActivityHelper.stop();
        OpenCVCameraViewListener.getInstance().registerOnFrameCallbackListener(null);
        if (controlLoopThread != null) {
            controlLoopThread.setRunning(false);
            try {
                controlLoopThread.join();
            } catch (InterruptedException ex) {
            }
        }
    }

    /**
     * This method is called by the OpenCV Camera Thread independent of the FTC loop() method.
     * @param in
     * @return
     */
    @Override
    public Mat process(Mat in) {
        return in;
    }
}
