package org.lapeerftcrobotics.control;

import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.GyroSensor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.util.Range;

/**
 *
 */
public class RobotController {

    private final static double DRIVE_MOTOR_POWER_RAMP_RATE = 0.03; // 0.04

    private double leftDriveMotorPowerTarget = 0.0;
    private double leftDriveMotorPower = 0.0;
    private double rightDriveMotorPowerTarget = 0.0;
    private double rightDriveMotorPower = 0.0;

    private DcMotor frontLeftDriveMotor;
    private DcMotor rearLeftDriveMotor;
    private DcMotor frontRightDriveMotor;
    private DcMotor rearRightDriveMotor;

    private GyroSensor gyroSensor = null;

    public RobotController() {

    }

    public void setGyroSensor(GyroSensor gs) {
        this.gyroSensor = gs;
    }

    public GyroSensor getGyroSensor() {
        return this.gyroSensor;
    }

    public void setLeftDriveMotorPowerTarget(double t) {
        this.leftDriveMotorPowerTarget = t;
    }

    public void setRightDriveMotorPowerTarget(double t) {
        this.rightDriveMotorPowerTarget = t;
    }

    public void processFast() {
    }

    public void init(HardwareMap hardwareMap) {
        frontLeftDriveMotor = hardwareMap.dcMotor.get("flm");
        frontRightDriveMotor = hardwareMap.dcMotor.get("frm");
        rearLeftDriveMotor = hardwareMap.dcMotor.get("rlm");
        rearRightDriveMotor = hardwareMap.dcMotor.get("rrm");
        gyroSensor = hardwareMap.gyroSensor.get("gyro");
        // calibrate the gyro.
        gyroSensor.calibrate();
    }

    public void process() {

        leftDriveMotorPower = leftDriveMotorPowerTarget;
        rightDriveMotorPower = rightDriveMotorPowerTarget;

        leftDriveMotorPower = rateLimitValue(leftDriveMotorPowerTarget, leftDriveMotorPower, DRIVE_MOTOR_POWER_RAMP_RATE, false);
        rightDriveMotorPower = rateLimitValue(rightDriveMotorPowerTarget, rightDriveMotorPower, DRIVE_MOTOR_POWER_RAMP_RATE, false);

        Range.clip(leftDriveMotorPower, -1.0, 1.0);
        Range.clip(rightDriveMotorPower, -1.0, 1.0);

        frontLeftDriveMotor.setPower(-leftDriveMotorPower);
        frontRightDriveMotor.setPower(rightDriveMotorPower);
        rearLeftDriveMotor.setPower(-leftDriveMotorPower);
        rearRightDriveMotor.setPower(rightDriveMotorPower);
    }

    private double rateLimitValue(double target, double power, double rate, boolean servo) {
        double command = power;
        if (target > command) {
            command += rate;
            if (command > target)
                command = target;
        } else {
            command -= rate;
            if (command < target)
                command = target;
        }

        if (command > 1.0) {
            command = 1.0;
        } else if ((servo) && (command < 0.0)) {
            command = 0.0;
        } else if (command < -1.0) {
            command = -1.0;
        }

        return command;
    }

}