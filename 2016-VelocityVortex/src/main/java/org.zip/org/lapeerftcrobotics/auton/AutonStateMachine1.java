package org.lapeerftcrobotics.auton;

import com.qualcomm.robotcore.robot.Robot;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.AutonOp;
import org.lapeerftcrobotics.control.RobotController;

/**
 * Created by User on 10/14/2016.
 */
public class AutonStateMachine1 implements AutonStateMachineInterface {

    private int state = -1;
    private int stateCnt = 0;

    private AutonOp autonOp = null;
    private RobotController robotController = null;
    private ElapsedTime runtime = null;

    public AutonStateMachine1() {

    }

    public void setAutonOp(AutonOp a) {
        this.autonOp = a;
    }

    @Override
    public void setRobotController(RobotController r) {
        this.robotController = r;
    }

    @Override
    public void setRuntime(ElapsedTime r) {
        this.runtime = r;
    }

    public void process() {

        int nextState = this.state;

        // 30ms each stateCnt

        switch(state) {
            case 0:
                break;

        }

        if (nextState != this.state) {
            this.state = nextState;
            this.stateCnt = 0;
        }
        else {
            this.stateCnt++;
        }
    }

    public int getState() {
        return this.state;
    }

}
