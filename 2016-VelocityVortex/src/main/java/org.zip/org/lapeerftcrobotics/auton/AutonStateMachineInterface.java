package org.lapeerftcrobotics.auton;

import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.teamcode.AutonOp;
import org.lapeerftcrobotics.control.RobotController;

/**
 * Created by User on 10/14/2016.
 */
public interface AutonStateMachineInterface {

    public void process();

    public int getState();

    public void setAutonOp(AutonOp a);
    
    public void setRobotController(RobotController r);

    public void setRuntime(ElapsedTime runtime);
}
